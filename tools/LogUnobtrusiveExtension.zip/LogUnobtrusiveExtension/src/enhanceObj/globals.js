// add public methods to logEnhancerObj
this.enhanceLogger = enhanceLogger;
this.exposeSafeLog = exposeSafeLog;