// Test Helpers
var $log = {};